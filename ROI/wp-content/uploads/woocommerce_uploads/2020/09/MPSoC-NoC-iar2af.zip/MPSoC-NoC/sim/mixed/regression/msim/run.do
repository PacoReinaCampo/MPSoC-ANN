run -all
quit
